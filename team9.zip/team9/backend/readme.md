# Backend Directory

This folder contains all files and components related to the **backend development** of the Online Bookstore project.