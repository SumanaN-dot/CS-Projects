Instructions
Download the attached file for the assignment Instructions and rubrics. 

The actual due date/time is your demo time. The demo schedule will be available on the content page. Each team should decide on who and when to schedule their demo and sign up for the demo on the demo schedule. 

Demonstration requirements:

1) The total demo duration is 15 minutes for each team. (10 minutes for you to demonstrate your work and 5 minutes question/answer)

2) Be ready on time, and demonstrate all the system functionality by showing the UI design of your system. You should demonstrate the proposed execution paths of the system, showing all pages, within 10 minutes. The TA will ask questions during the remaining 5 minutes.

 You must submit the code as one compressed file to eLC before your demo time.

(Check the syllabus for late penalties)

Due on Jul 6, 2025 11:59 PM
Available on Jun 24, 2025 12:01 AM. Access restricted before availability starts.