links:

> [Team_Contract](https://outlookuga-my.sharepoint.com/:w:/r/personal/scn83330_uga_edu/_layouts/15/Doc.aspx?sourcedoc=%7B077782F2-AD1A-4624-9BD8-E64A870599F5%7D&file=Team_Contract%20elc.docx&wdLOR=c43CEB318-CEDB-AD47-90FE-84DD0C11F6E8&fromShare=true&action=default&mobileredirect=true)


1. [Deliverable1_UserStories.docx](https://outlookuga-my.sharepoint.com/:w:/r/personal/scn83330_uga_edu/Documents/Cover_Page.docx?d=w2d8507f9f1ac4949bd45561ecc34de45&e=4%3a066c53a440a54041af7b15bb3ae16b36&sharingv2=true&fromShare=true&at=9)

- [Deliverable 1 UserStories.pdf](https://github.com/nimadarbandi/team9/blob/main/_docs/deliverables/D1/Deliverable%102%20UserStories.pdf)


2. [Deliverable2_UseCases.docx](https://outlookuga-my.sharepoint.com/:w:/r/personal/aci27367_uga_edu/Documents/Team9_Deliverable2_UseCases.docx?d=w4efd913b78f6457094fb12a43f7bf90f&e=4%3a14ccabc9d33e4132b2d82fde1b8b81d7&sharingv2=true&fromShare=true&at=9
)

- [Deliverable2_Use_Case_Diagram.mdj](https://github.com/nimadarbandi/team9/blob/main/_docs/diagrams/Deliverable2_Use_Case_Diagram.mdj)

- [Deliverable 2 Use case document.pdf](https://github.com/nimadarbandi/team9/blob/main/_docs/deliverables/D2/Deliverable%202%20Use%20case%20documentSU25.pdf)


3. [Deliverable3 instructions](https://github.com/nimadarbandi/team9/blob/main/_docs/deliverables/D3/readme.md)

- [Deliverable 3 UI and rubrics.pdf](https://github.com/nimadarbandi/team9/blob/main/_docs/deliverables/D3/Deliverable%203%20UI%20and%20rubrics.pdf)


4. [Deliverable4_DomainClassDiagram.docx](https://outlookuga-my.sharepoint.com/:w:/r/personal/scn83330_uga_edu/_layouts/15/Doc.aspx?sourcedoc=%7B31CB83F0-5008-44DE-B727-0B1EE3115F04%7D&file=Deliverable4.docx&wdLOR=c11E200E7-9FA1-9649-A161-C8D460E576D1&fromShare=true&action=default&mobileredirect=true)

- [Deliverable 4 Domain Class Diagram.pdf](https://github.com/nimadarbandi/team9/blob/main/_docs/deliverables/D4/Deliverable%204%20Domain%20class%20diagram.pdf)


5. [Deliverable5 ObjectRelationalMapping.docx](https://outlookuga-my.sharepoint.com/:w:/r/personal/aci27367_uga_edu/_layouts/15/Doc.aspx?sourcedoc=%7BD9A25F3C-9E64-4B45-A640-F40B1B5CA748%7D&file=Team9_Deliverable5_ORM.docx&wdLOR=c93DB3B40-DF26-5A4A-99A0-17F361251524&fromShare=true&action=default&mobileredirect=true)

- [Deliverable 5 Object relational mapping.pdf](https://github.com/nimadarbandi/team9/blob/main/_docs/deliverables/D5/Deliverable%205%20Object%20relational%20mapping.pdf)


6. [Deliverable6_BookstoreSprint2_Stories.docx]()

- [Deliverable 6_Bookstore Sprint 2 Stories.pdf](https://github.com/nimadarbandi/team9/blob/main/_docs/deliverables/D6/Deliverable%206%20Bookstore%20Sprint2%20Stories.pdf)

