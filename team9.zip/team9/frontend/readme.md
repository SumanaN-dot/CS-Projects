# Frontend Directory

This folder contains all files and components related to the **frontend development** of the Online Bookstore project.